package com.example.demo.user.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Table(name = "u")
public class User {

    @Id
    @Column(name = "ID", nullable = false)
    private String id;

    @Column(name = "PW",  nullable = false)
    private String pw;

    @Builder
    public User(String id, String pw) {
        this.id = id;
        this.pw = pw;
    }
}
