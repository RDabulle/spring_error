package com.example.demo.user.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Table(name = "u")
public class User {

    @Id
    @Column(name = "ID", nullable = false)
    private String id;

    @Column(name = "PW",  nullable = false)
    private String pw;

    @Column(name = "EMAIL",  nullable = false)
    private String email;

    @Column(name = "NAME",  nullable = false)
    private String name;

    @Column(name = "INTRODUCTION",  nullable = false)
    private String introduction;

    @Column
    private boolean UserUse = true;

    @Builder
    public User(String id, String pw, String email, String name, String introduction) {
        this.id = id;
        this.pw = pw;
        this.email = email;
        this.name = name;
        this.introduction = introduction;
    }

    public void updata(String pw, String email, String name, String introduction) {
        this.pw = pw;
        this.email = email;
        this.name = name;
        this.introduction = introduction;
    }

    public void changeUse(boolean UserUse) {
        this.UserUse = UserUse;
    }
}
