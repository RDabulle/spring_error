package com.example.demo.user.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
public class UserPatchDto {
    private String pw;
    private String email;
    private String name;
    private String introduction;

    @Builder
    public UserPatchDto(String pw, String email, String name, String introduction) {
        this.pw = pw;
        this.email = email;
        this.name = name;
        this.introduction = introduction;
    }
}
