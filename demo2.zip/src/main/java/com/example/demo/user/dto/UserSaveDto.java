package com.example.demo.user.dto;

import com.example.demo.user.entity.User;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class UserSaveDto {

    private String id;
    private String pw;
    private String email;
    private String name;
    private String introduction;

    @Builder
    public UserSaveDto(String id, String pw, String email, String name, String introduction) {
        this.id = id;
        this.pw = pw;
        this.email = email;
        this.name = name;
        this.introduction = introduction;
    }

/*    public User toEntity() {
        return User.builder()
                .id(id)
                .pw(pw)
                .email(email)
                .name(name)
                .introduction(introduction)
                .build();
    }*/
}
